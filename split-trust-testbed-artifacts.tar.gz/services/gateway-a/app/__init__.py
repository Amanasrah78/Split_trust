"""Gateway A service."""
