"""Gateway B service."""
