"""Session Authorization Controller service."""
